package com.cognizant.ems.entities;

import java.util.List;

public class StudentDTO {

		

	}



