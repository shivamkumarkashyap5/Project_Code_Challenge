package com.cognizant.ems.entities;

import java.util.List;

public class CourseDTO {

		private List<Course> course;

		public List<Course> getCourse() {
			return course;
		}

		public void setCourse(List<Course> course) {
			this.course = course;
		}
		
		

	}



