package com.restapi.mstock.dao;

import java.util.List;

import com.restapi.mstock.models.Stock;

public interface StockDao {
	
public List<Stock> getstockcompare(String company,String fromdate, String todate);
}
