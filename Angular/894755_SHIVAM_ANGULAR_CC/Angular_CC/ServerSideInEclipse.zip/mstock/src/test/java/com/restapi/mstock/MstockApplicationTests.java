package com.restapi.mstock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MstockApplicationTests {

	@Test
	void contextLoads() {
	}

}
